import React from "react";
import AppWorks  from "../components/home/works";

function AppWorks() {
    return (
        <AppWorks />
    )
}

export default AppWorks;