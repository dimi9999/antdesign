import React from "react";
import AppAbout  from "../components/home/about";

function AppAbout() {
    return (
        <AppAbout />
    )
}

export default AppAbout;