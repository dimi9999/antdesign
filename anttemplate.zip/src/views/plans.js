import React from "react";
import AppPlans  from "../components/home/plans";

function AppPlans() {
    return (
        <AppPlans />
    )
}

export default AppPlans;