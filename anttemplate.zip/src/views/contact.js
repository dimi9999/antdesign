import React from "react";

function AppContact() {
    return (
        <div className="main">
            <AppCarousel />
        </div>
    )
}

export default AppContact;