import React from "react";
import AppFaq  from "../components/home/faq";

function AppFaq() {
    return (
        <AppFaq />
    )
}

export default AppFaq;