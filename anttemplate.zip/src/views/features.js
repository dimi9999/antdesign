import React from "react";
import AppFeatures  from "../components/home/features";

function AppFeatures() {
    return (
        <AppFeatures />
    )
}

export default AppFeatures;